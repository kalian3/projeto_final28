import tkinter as tk
from ttkbootstrap.dialogs import DatePickerDialog

root = tk.Tk()

dp = DatePickerDialog()

root.mainloop()