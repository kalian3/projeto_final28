

class FileBrowser:

    def __init__(self, parent, initialdir="", initialfile="", mode="openfile", 
                 multipleselection=False, message="", title="Open File", 
                 filetypes=[], okbuttontext="Ok", cancelbuttontext="Cancel", 
                 createfolders=True
                 ):
        ...

    
class Stats:

    ...



