# 分隔线

此小部件样式可以用默认颜色（通常为灰色）或[选定颜色](index.md#colors)来绘制细直线或垂线。 

![separator](../assets/widget-styles/separator.png)

```python
# 默认分隔线样式
Separator()

# 彩色分隔符样式 'info'
Separator(bootstyle="info")
```
