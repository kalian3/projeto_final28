# Frame

This widget style features a default background color that matches the theme
background by default, or the [selected color](index.md#colors).

![frame](../assets/widget-styles/frame.png)

```python
# default frame style
Frame()

# info colored frame style
Frame(bootstyle="info")
```