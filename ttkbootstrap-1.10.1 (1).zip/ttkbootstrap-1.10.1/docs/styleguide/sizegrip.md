# Sizegrip

This widget style features a pattern of squares in a default muted color
by default, or the [selected color](index.md#colors).

![sizegrip](../assets/widget-styles/sizegrip.gif)

```python
# default sizegrip style
Sizegrip()

# info colored sizegrip style - handle color
Sizegrip(bootstyle="info")
```
