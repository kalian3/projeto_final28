# MessageDialog

::: ttkbootstrap.dialogs.MessageDialog
    selection:
        filters: ["!^_", "^__init__"]
    rendering:
        heading_level: 2
        show_root_heading: true