# ColorChooserDialog

::: ttkbootstrap.dialogs.colorchooser.ColorChooserDialog
    selection:
        filters: ["!^_", "^__init__"]
    rendering:
        heading_level: 2
        show_root_heading: true
