# 安装

这是很容易的。

!!! note "通过PyPI安装"
    ```bash
    python -m pip install ttkbootstrap
    ```

!!! note "通过PyPI清华镜像源安装-译者注"
    ```bash
    python -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple ttkbootstrap
    ```

未经过测试的版本（可能会出错）<s>（注：译者可能翻译有误）</s>

!!! note "通过Github安装"
    ```bash
    python -m pip install git+https://github.com/israel-dryer/ttkbootstrap
    ```


