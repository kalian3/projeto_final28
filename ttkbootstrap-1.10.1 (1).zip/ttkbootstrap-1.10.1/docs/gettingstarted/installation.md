# Installation

Easy peezy.

!!! note "PyPI Installation"
    ```bash
    python -m pip install ttkbootstrap
    ```

Lemon squeeze.

!!! note "Github Installation"
    ```bash
    python -m pip install git+https://github.com/israel-dryer/ttkbootstrap
    ```


