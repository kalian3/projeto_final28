# 深色主题

以下深色主题很大程度上受到 [https://bootswatch.com/](https://bootswatch.com/) 的启发

![solar 主题](../assets/themes/solar.png)
[灵感来源](https://bootswatch.com/solar/)

![superhero 主题](../assets/themes/superhero.png)
[灵感来源](https://bootswatch.com/superhero/)

![darkly 主题](../assets/themes/darkly.png)
[灵感来源](https://bootswatch.com/darkly/)

![cyborg 主题](../assets/themes/cyborg.png)
[灵感来源](https://bootswatch.com/cyborg/)

![vapor 主题](../assets/themes/vapor.png)
[灵感来源](https://bootswatch.com/vapor/)