# Dark themes

The following dark themes are largly inspired by [https://bootswatch.com/](https://bootswatch.com/)

![solar theme](../assets/themes/solar.png)
Source of [inspiration](https://bootswatch.com/solar/)

![superhero theme](../assets/themes/superhero.png)
Source of [inspiration](https://bootswatch.com/superhero/)

![darkly theme](../assets/themes/darkly.png)
Source of [inspiration](https://bootswatch.com/darkly/)

![cyborg theme](../assets/themes/cyborg.png)
Source of [inspiration](https://bootswatch.com/cyborg/)

![vapor theme](../assets/themes/vapor.png)
Source of [inspiration](https://bootswatch.com/vapor/)

