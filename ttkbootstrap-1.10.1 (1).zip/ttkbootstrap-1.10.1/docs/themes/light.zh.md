# 浅色主题

以下浅色主题很大程度上受到 [https://bootswatch.com/](https://bootswatch.com/) 的启发

![cosmo 主题](../assets/themes/cosmo.png)
[灵感来源](https://bootswatch.com/cosmo/)

![flatly 主题](../assets/themes/flatly.png)
[灵感来源](https://bootswatch.com/flatly/)

![journal 主题](../assets/themes/journal.png)
[灵感来源](https://bootswatch.com/journal/)

![litera 主题](../assets/themes/litera.png)
[灵感来源](https://bootswatch.com/litera/)

![lumen 主题](../assets/themes/lumen.png)
[灵感来源](https://bootswatch.com/lumen/)

![minty 主题](../assets/themes/minty.png)
[灵感来源](https://bootswatch.com/minty/)

![pulse 主题](../assets/themes/pulse.png)
[灵感来源](https://bootswatch.com/pulse/)

![sandstone 主题](../assets/themes/sandstone.png)
[灵感来源](https://bootswatch.com/sandstone/)

![united 主题](../assets/themes/united.png)
[灵感来源](https://bootswatch.com/united/)

![yeti 主题](../assets/themes/yeti.png)
[灵感来源](https://bootswatch.com/yeti/)

![morph 主题](../assets/themes/morph.png)
[灵感来源](https://bootswatch.com/morph/)

![simplex 主题](../assets/themes/simplex.png)
[灵感来源](https://bootswatch.com/simplex/)

![cerculean 主题](../assets/themes/cerculean.png)
[灵感来源](https://bootswatch.com/cerulean/)