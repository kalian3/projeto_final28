# 食谱

越来越多的食谱展示了如何在 ttkbootstrap 中做特定的事情。
<br><br>

![食谱](../assets/cookbook/code-cooking.jfif)