# Gallery

In this section you will find a growing list of ttkbootstrap projects meant to 
provide inspiration or direction when creating your own applications. These are 
meant to demonstrate design and are not necessarily fully functional applications.

![file search image example](../assets/gallery/back_me_up.png)